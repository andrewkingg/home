import React from 'react';
import './App.css';

class Header extends React.Component {
  render() {
    return (
      <div className = "header">
      <div className="headerBanner">
        <div style={{ height: '80%', width: '90%', paddingLeft: '30px', paddingTop: '15px' }}>
          <span> "If you </span>
          <span className='pink'>work hard</span>
          <span> enough, and use your mind and </span>
          <span className='yellow'>imagination</span>
          <span>, you can shape the world to your</span>
          <span className='green'> desires</span>
          <span>"</span>
        </div>
        </div>
        <div className="navbarHeader"> Hello </div>
        </div>
      
    );
  }
}

export default Header;
