import React from 'react';
import './App.css';
import Home from './Home.js'
import PageTemplate from './PageTemplate.js'


class App extends React.Component {
  render() {
    return (
      <div className="App">
        <PageTemplate>
          <Home />
        </PageTemplate>
      </div>
    );
  }
}

export default App;
